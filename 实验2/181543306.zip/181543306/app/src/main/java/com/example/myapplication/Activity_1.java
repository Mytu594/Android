package com.example.myapplication;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class Activity_1 extends AppCompatActivity{
	//用户名
	EditText userNameTxt;
	//密码
	EditText passwordTxt;
	//登录按钮
	Button loginBtn;
	//重置按钮
	Button resetBtn;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_1);
		//初始化各个组件
		userNameTxt =(EditText)findViewById(R.id.userNameTxt);
		passwordTxt = (EditText) findViewById(R.id.passwordTxt);
		loginBtn = (Button)findViewById(R.id.loginBtn);
		resetBtn = (Button)findViewById(R.id.resetBtn);
		//实现点击Button的业务逻辑
		loginBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				//获取用户名
				String userName = userNameTxt.getText().toString();
				//获取密码
				String password = passwordTxt.getText().toString();
//                //bundle用于存放多种数据
//                Bundle bundle=new Bundle();
				//结果
				String str="";
				//判断用户名
				if(!"admin".equals(userName)){
					str="用户名不存在！";
				}
				//判断密码
				if(!"1".equals(password)){
					str="密码错误！";
				}
				if("admin".equals(userName)&&"1".equals(password)){
					str="登录成功！";
				}
				Intent intent=new Intent(Activity_1.this, Activity_2.class);
				//结果放入intent发送
				intent.putExtra("结果",str);
				//如果只是发送一种数据类型，不需要用bundle，直接存入int或string变量
				startActivity(intent);

			}
		});
		resetBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				userNameTxt.setText(null);
				passwordTxt.setText(null);
				userNameTxt.requestFocus();
			}
		});
	}

}