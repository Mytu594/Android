package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Activity_2 extends AppCompatActivity
{
	private TextView tx;
	private Button bt;
	@Override
	protected void onCreate( Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_2);
		tx= (TextView) findViewById(R.id.tx_jieguo);
		Intent intent=getIntent();
		// 从intent获取登录结果
		String str="";
		str=intent.getStringExtra("结果");

		//显示结果
		tx.setText(	str);

		// 按钮关闭本activity，退回上一个activity
		bt = (Button) findViewById(R.id.back);
		bt.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {

				finish();
			}
		});
	}
}